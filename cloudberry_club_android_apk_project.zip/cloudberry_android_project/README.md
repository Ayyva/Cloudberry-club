# Cloudberry Club for Android

This is an Android Studio project that wraps the current Cloudberry Club mobile app in a native Android WebView shell. The HTML, game logic and procedurally generated ambience are packaged inside the APK, so the app itself does not need to fetch audio or page assets from the internet.

## Build an installable debug APK

### With Android Studio (easiest)
1. Install Android Studio and the Android SDK Platform 35 (Android Studio's SDK Manager can install it).
2. Extract this project ZIP.
3. In Android Studio, choose **Open** and select the `CloudberryClubAndroid` project folder.
4. Let Gradle sync finish. The included `gradlew` bootstrap script downloads Gradle 8.9 when it is not already cached, so the first build needs an internet connection. Android Gradle Plugin and AndroidX WebKit dependencies also need to download once.
5. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. The installable debug APK is written to:

   `app/build/outputs/apk/debug/app-debug.apk`

Copy that APK to your Android phone and open it to install. Android may ask you to allow installs from the app you used to open the file.

### From Linux terminal

Install Android Studio's Android SDK Platform 35 and Build Tools first. Then from this project folder, run:

```bash
./gradlew assembleDebug
```

The APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

If Gradle cannot find your Android SDK, set `ANDROID_HOME` or `ANDROID_SDK_ROOT` to the SDK folder shown in Android Studio's SDK Manager. The build requires a JDK 17 or newer compatible with Android Gradle Plugin 8.7.3.

## App details

- Package ID: `com.cloudberry.club`
- Minimum Android version: Android 6.0 (API 23)
- Compile / target SDK: 35
- WebView loads packaged HTML at the stable HTTPS-style origin provided by `WebViewAssetLoader`; browser local storage is enabled to persist app data on the device.
- Ambient sounds are generated with the Web Audio API only after the user taps a control.
- No camera, microphone, contacts, location, or notification permission is requested.

The included debug APK (once built) is installable, but it is signed with Android's standard debug key. For Play Store distribution, create a release signing key and configure a signed release build.

## Build without installing Android Studio locally

A GitHub Actions workflow is included at `.github/workflows/build-apk.yml`. Follow `GET-APK.txt` to have GitHub build the debug APK and provide it as a downloadable artifact. This environment cannot compile the APK directly because Android SDK/Gradle build tools are unavailable here.
