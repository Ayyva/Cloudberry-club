#!/bin/sh
set -eu
cd "$(dirname "$0")"
if [ -z "${ANDROID_HOME:-}" ] && [ -z "${ANDROID_SDK_ROOT:-}" ]; then
  for candidate in "$HOME/Android/Sdk" "$HOME/Android/sdk" "$HOME/.android/sdk" /opt/android-sdk /usr/lib/android-sdk; do
    if [ -d "$candidate/platforms" ]; then
      export ANDROID_HOME="$candidate"
      break
    fi
  done
fi
if [ -z "${ANDROID_HOME:-}" ] && [ -z "${ANDROID_SDK_ROOT:-}" ]; then
  echo "Android SDK not found. Install Android Studio + SDK Platform 35, then set ANDROID_HOME or ANDROID_SDK_ROOT." >&2
  exit 2
fi
./gradlew assembleDebug
echo
echo "APK built at: $(pwd)/app/build/outputs/apk/debug/app-debug.apk"
