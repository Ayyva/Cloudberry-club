@echo off
setlocal
set VERSION=8.9
set BASE=%USERPROFILE%\.gradle\cloudberry-distributions
set DIST=%BASE%\gradle-%VERSION%
if not exist "%DIST%\bin\gradle.bat" (
  if not exist "%BASE%" mkdir "%BASE%"
  echo Gradle %VERSION% is not cached; downloading it now...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip' -OutFile '%BASE%\gradle-%VERSION%-bin.zip'; Expand-Archive -Force '%BASE%\gradle-%VERSION%-bin.zip' '%BASE%'; Remove-Item '%BASE%\gradle-%VERSION%-bin.zip'"
  if errorlevel 1 exit /b 1
)
call "%DIST%\bin\gradle.bat" %*
endlocal
