package com.cloudberry.club;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.TextView;

/** Simple offline-first WebView shell for Cloudberry Club. */
public final class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            Window window = getWindow();
            window.setStatusBarColor(Color.rgb(255, 248, 251));
            window.setNavigationBarColor(Color.rgb(255, 248, 251));
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);

            FrameLayout root = new FrameLayout(this);
            root.setBackgroundColor(Color.rgb(255, 248, 251));
            webView = new WebView(this);
            webView.setBackgroundColor(Color.rgb(255, 248, 251));
            webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
            webView.setVerticalScrollBarEnabled(false);
            webView.setHorizontalScrollBarEnabled(false);

            WebSettings settings = webView.getSettings();
            settings.setJavaScriptEnabled(true);
            settings.setDomStorageEnabled(true);
            settings.setDatabaseEnabled(true);
            settings.setMediaPlaybackRequiresUserGesture(true);
            settings.setAllowFileAccess(true);
            settings.setAllowContentAccess(false);
            settings.setSupportZoom(false);
            settings.setBuiltInZoomControls(false);
            settings.setDisplayZoomControls(false);
            settings.setLoadsImagesAutomatically(true);

            webView.setWebChromeClient(new WebChromeClient() {
                @Override
                public boolean onJsAlert(WebView view, String url, String message,
                                         android.webkit.JsResult result) {
                    new AlertDialog.Builder(MainActivity.this)
                            .setMessage(message)
                            .setPositiveButton(android.R.string.ok,
                                    (dialog, which) -> result.confirm())
                            .setOnCancelListener(dialog -> result.cancel())
                            .show();
                    return true;
                }
            });

            root.addView(webView, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT));
            setContentView(root);
            webView.loadUrl("file:///android_asset/index.html");
        } catch (Throwable error) {
            showStartupError(error);
        }
    }

    private void showStartupError(Throwable error) {
        String details = error.getClass().getSimpleName() + ": " + String.valueOf(error.getMessage());
        TextView message = new TextView(this);
        message.setText("Cloudberry Club couldn't start. Please send this message for troubleshooting:\n\n" + details);
        message.setTextColor(Color.rgb(90, 55, 80));
        message.setTextSize(16);
        message.setPadding(32, 48, 32, 32);
        message.setBackgroundColor(Color.rgb(255, 248, 251));
        setContentView(message);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        new AlertDialog.Builder(this)
                .setTitle("Take a little cloud break?")
                .setMessage("Your progress is saved on this device when browser storage is available.")
                .setNegativeButton("Stay here", (dialog, which) -> dialog.dismiss())
                .setPositiveButton("Close app", (dialog, which) -> finish())
                .show();
    }

    @Override
    protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.loadUrl("about:blank");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
